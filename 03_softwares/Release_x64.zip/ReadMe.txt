本软件是免费开源软件 使用LGPLv3许可证
This software is free and open source software licensed under LGPLv3
https://github.com/Maplespe/ExplorerBlurMica

更新日志(update log)：

1.0.6 2023-5-1
增加新的配置文件选项: 
- showLine : 该选项指定是否在主视图的TreeView和预览面板之间显示一条分隔线。 true或者false
- darkRibbon : Ribbon的文本颜色和背景在Windows 10 Light模式下呈现不正确, 这个选项允许你将Ribbon设置为Dark模式，以缓解这一问题。
详情请看ReadMe


修复了Windows 10 Acrylic效果超出窗口边框的问题 smallBorder选项现在默认false


Add new feature settings
- showLine : This option specifies whether to show a separator line between the TreeView and the preview panel in the main view.
- darkRibbon : Ribbon text colors and backgrounds are rendered incorrectly in Windows 10 Light mode.
This option allows you to set the ribbon to dark mode to alleviate this problem.
For more information, please see ReadMe.

Fixed Windows 10 Acrylic effect out of window border issue. smallBorder option now defaults to false

--------------------------------------------------------------------------

1.0.5 2023-4-29
修复了与StartAllBack等软件调节导航栏相关的功能的兼容性问题 #17
修复了控制面板的部分渲染问题和通过shell方式打开特定页面渲染效果异常的问题
优化了程序效率和代码

Fixed the compatibility issue with the function of modifying the navigation bar with software such as StartAllBack #17
Fixed some rendering issues in the control panel and the issue of rendering abnormalities when opening certain pages via shell.
Optimized program efficiency and code.

--------------------------------------------------------------------------

1.0.4 2023-1-12
修复了特定情况下可能出现背景渲染错误的问题 #10
修复了控制面板命令模块和导航栏渲染错误的问题 #9
修复了微软输入法文字颜色渲染错误的问题 #8

Fixed possible rendering errors in certain cases #10
Fixed control panel's command module and navbar rendering errors #9
Fixed Microsoft IME input text rendering error in edit box #8

--------------------------------------------------------------------------

1.0.3 2022-11-21
修复了win10 dark 主题颜色下地址栏不透明的问题 #7
修复了win10 配置文件 Blur效果和Acrylic效果参数ID相反的问题

Fixed the problem that the Win10 dark address bar was opaque #7
Fixed the problem that the Blur effect of the win10 configuration file was opposite to the Acrylic effect parameter ID.

--------------------------------------------------------------------------

1.0.2 2022-10-22
支持Windows 22H2系统 支持多标签页 #5
修复了Windows11 最左边有白色竖条的问题
修复了Windows11 暗色模式下地址栏不透明的问题
增强了程序稳定性
增加了Windows11的Acrylic支持 Mica效果现在为effect=2

Support Windows 22H2 system supports multiple tabs #5
Fixed the problem of white vertical bar on the left of WIndows11
Fixed the problem of opaque address bar in Windows 11 dark mode
The program stability is enhanced
Added Acrylic support for Windows 11, Mica effect is now effect=2

--------------------------------------------------------------------------

1.0.1 2022-8-27
Fixed the bug of opaque ribbon bar in Windows 10 English language system